const EmergencyContact = require('../models/EmergencyContact');

// @desc    Add emergency contact
// @route   POST /api/contacts
const addContact = async (req, res) => {
    try {
        const { name, phone, relation, email } = req.body;
        const userId = req.user.id;

        const count = await EmergencyContact.count({ where: { userId, isActive: true } });
        if (count >= 5) {
            return res.status(400).json({ success: false, message: 'Maximum 5 emergency contacts allowed' });
        }

        const contact = await EmergencyContact.create({ userId, name, phone, relation, email });
        res.status(201).json({ success: true, message: 'Contact added', data: contact });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get all contacts for user
// @route   GET /api/contacts
const getContacts = async (req, res) => {
    try {
        const contacts = await EmergencyContact.findAll({
            where: { userId: req.user.id, isActive: true },
            order: [['createdAt', 'ASC']],
        });
        res.json({ success: true, data: contacts });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update emergency contact
// @route   PUT /api/contacts/:id
const updateContact = async (req, res) => {
    try {
        const contact = await EmergencyContact.findOne({
            where: { id: req.params.id, userId: req.user.id },
        });
        if (!contact) return res.status(404).json({ success: false, message: 'Contact not found' });

        await contact.update(req.body);
        res.json({ success: true, message: 'Contact updated', data: contact });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Delete emergency contact
// @route   DELETE /api/contacts/:id
const deleteContact = async (req, res) => {
    try {
        const contact = await EmergencyContact.findOne({
            where: { id: req.params.id, userId: req.user.id },
        });
        if (!contact) return res.status(404).json({ success: false, message: 'Contact not found' });

        await contact.update({ isActive: false });
        res.json({ success: true, message: 'Contact removed' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

module.exports = { addContact, getContacts, updateContact, deleteContact };
