const EmergencyAlert = require('../models/EmergencyAlert');
const EmergencyContact = require('../models/EmergencyContact');
const LocationHistory = require('../models/LocationHistory');
const SafeZone = require('../models/SafeZone');
const User = require('../models/User');
const path = require('path');
const fs = require('fs');

// =============================================
// AI Risk Analysis Engine (Enhanced)
// =============================================
const analyzeRisk = (lat, lng, hour) => {
    const isNight = hour >= 20 || hour <= 6;
    const isLateNight = hour >= 23 || hour <= 4;

    // Base environmental score
    const nightRisk = isLateNight ? 45 : isNight ? 30 : 0;
    const locationRisk = Math.floor(Math.random() * 35) + 10;
    const totalScore = Math.min(100, nightRisk + locationRisk);

    let level = 'LOW';
    if (totalScore >= 75) level = 'CRITICAL';
    else if (totalScore >= 55) level = 'HIGH';
    else if (totalScore >= 35) level = 'MEDIUM';

    const tips = {
        CRITICAL: [
            '🆘 Call 112 immediately — police dispatched',
            '🏃 Move to nearest crowded public place',
            '📢 Make noise, attract attention',
            '🔒 Lock yourself in nearest safe building',
            '👥 Alert all emergency contacts now'
        ],
        HIGH: [
            '⚠️ Stay in well-lit, populated areas',
            '📍 Share your live location with family',
            '📞 Keep 112 on speed dial',
            '🏃 Avoid isolated streets and alleys',
            '👀 Trust your instincts — leave if uncomfortable'
        ],
        MEDIUM: [
            '🌟 Be aware of your surroundings',
            '🔦 Stay in lit areas — avoid dark lanes',
            '📱 Ensure phone is charged',
            '👥 Walk with someone if possible',
            '🗺️ Plan your route before moving'
        ],
        LOW: [
            '✅ Area is generally safe right now',
            '🛡️ Normal safety precautions apply',
            '📍 App is monitoring your location',
            '🔔 Shake phone or say HELP for emergency'
        ]
    };

    return { score: totalScore, level, tips: tips[level], isNight, isLateNight };
};

// =============================================
// POST /api/emergency/sos — Trigger SOS
// =============================================
const triggerSOS = async (req, res) => {
    try {
        const { latitude, longitude, address, alertType = 'SOS' } = req.body;
        const userId = req.user.id;
        const hour = new Date().getHours();
        const risk = analyzeRisk(latitude, longitude, hour);

        const alert = await EmergencyAlert.create({
            userId,
            alertType,
            latitude,
            longitude,
            address: address || `${parseFloat(latitude).toFixed(4)}, ${parseFloat(longitude).toFixed(4)}`,
            riskLevel: risk.level,
            riskScore: risk.score,
            status: 'ACTIVE',
        });

        // Log initial location
        if (latitude && longitude) {
            await LocationHistory.create({
                userId, alertId: alert.id,
                latitude, longitude, address,
                isEmergency: true,
            });
        }

        // Get emergency contacts
        const contacts = await EmergencyContact.findAll({ where: { userId, isActive: true } });
        const user = await User.findByPk(userId, { attributes: ['name', 'phone'] });

        // Emit via Socket.IO
        const io = req.app.get('io');
        if (io) {
            io.emit('emergency_alert', {
                alertId: alert.id, userId, userName: user?.name,
                riskLevel: risk.level, riskScore: risk.score,
                latitude, longitude, address,
                alertType, timestamp: new Date(),
            });
            // Also emit to user-specific room
            io.to(`user_${userId}`).emit('sos_confirmed', { alertId: alert.id, riskLevel: risk.level });
        }

        console.log(`🚨 SOS [${alertType}] by user ${userId} — Risk: ${risk.level} (${risk.score}) — ${contacts.length} contacts`);

        res.status(201).json({
            success: true,
            message: '🚨 Emergency Alert Triggered!',
            data: {
                alertId: alert.id,
                riskLevel: risk.level,
                riskScore: risk.score,
                safetyTips: risk.tips,
                contactsNotified: contacts.length,
                contacts: contacts.map(c => ({ name: c.name, phone: c.phone })),
                status: 'ACTIVE',
                isNightTime: risk.isNight,
            },
        });
    } catch (error) {
        console.error('SOS Error:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// PUT /api/emergency/location — Live GPS Update
// =============================================
const updateLocation = async (req, res) => {
    try {
        const { latitude, longitude, address, alertId, speed, accuracy } = req.body;
        const userId = req.user.id;

        const location = await LocationHistory.create({
            userId, alertId: alertId || null,
            latitude, longitude, address,
            speed: speed || 0,
            accuracy: accuracy || 0,
            isEmergency: !!alertId,
        });

        await User.update(
            { lastLocation: { latitude, longitude, updatedAt: new Date() } },
            { where: { id: userId } }
        );

        const io = req.app.get('io');
        if (io) {
            io.emit(`location_update_${userId}`, { latitude, longitude, address, timestamp: new Date() });
        }

        res.json({ success: true, message: 'Location updated', data: location });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// PUT /api/emergency/:id/resolve
// =============================================
const resolveAlert = async (req, res) => {
    try {
        const alert = await EmergencyAlert.findOne({ where: { id: req.params.id, userId: req.user.id } });
        if (!alert) return res.status(404).json({ success: false, message: 'Alert not found' });
        await alert.update({ status: req.body.status || 'RESOLVED', resolvedAt: new Date() });
        res.json({ success: true, message: 'Alert updated', data: alert });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// GET /api/emergency/history
// =============================================
const getAlertHistory = async (req, res) => {
    try {
        const alerts = await EmergencyAlert.findAll({
            where: { userId: req.user.id },
            order: [['createdAt', 'DESC']],
            limit: 100,
        });
        res.json({ success: true, data: alerts });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// POST /api/emergency/risk-analysis — AI Risk
// =============================================
const getRiskAnalysis = async (req, res) => {
    try {
        const { latitude, longitude } = req.body;
        const hour = new Date().getHours();
        const risk = analyzeRisk(longitude, longitude, hour);

        res.json({
            success: true,
            data: {
                riskLevel: risk.level,
                riskScore: risk.score,
                safetyTips: risk.tips,
                isNightTime: risk.isNight,
                isLateNight: risk.isLateNight,
                analyzedAt: new Date(),
                location: { latitude, longitude },
            },
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// GET /api/emergency/stats — Dashboard Stats
// =============================================
const getDashboardStats = async (req, res) => {
    try {
        const userId = req.user.id;
        const [totalAlerts, activeAlerts, resolvedAlerts, contacts] = await Promise.all([
            EmergencyAlert.count({ where: { userId } }),
            EmergencyAlert.count({ where: { userId, status: 'ACTIVE' } }),
            EmergencyAlert.count({ where: { userId, status: 'RESOLVED' } }),
            EmergencyContact.count({ where: { userId, isActive: true } }),
        ]);
        res.json({ success: true, data: { totalAlerts, activeAlerts, resolvedAlerts, emergencyContacts: contacts } });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// GET /api/emergency/safe-zones — Police Stations from DB
// =============================================
const getSafeZones = async (req, res) => {
    try {
        const zones = await SafeZone.findAll({ where: { isVerified: true } });
        res.json({ success: true, data: zones });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// =============================================
// POST /api/emergency/upload-audio — Evidence Upload
// =============================================
const uploadAudio = async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ success: false, message: 'No audio file uploaded' });
        const alertId = req.body.alertId;

        if (alertId) {
            await EmergencyAlert.update(
                { audioRecordingPath: req.file.path },
                { where: { id: alertId, userId: req.user.id } }
            );
        }

        res.json({
            success: true,
            message: '🎙️ Audio evidence saved',
            data: { filename: req.file.filename, size: req.file.size, alertId }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

module.exports = {
    triggerSOS, updateLocation, resolveAlert,
    getAlertHistory, getRiskAnalysis, getDashboardStats,
    getSafeZones, uploadAudio
};
