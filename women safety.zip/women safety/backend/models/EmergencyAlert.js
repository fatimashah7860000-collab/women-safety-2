const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const EmergencyAlert = sequelize.define('EmergencyAlert', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: 'users', key: 'id' },
    },
    alertType: {
        type: DataTypes.ENUM('SOS', 'VOICE', 'SHAKE', 'AUTO'),
        allowNull: false,
        defaultValue: 'SOS',
    },
    status: {
        type: DataTypes.ENUM('ACTIVE', 'RESOLVED', 'FALSE_ALARM'),
        defaultValue: 'ACTIVE',
    },
    latitude: {
        type: DataTypes.DECIMAL(10, 8),
        allowNull: true,
    },
    longitude: {
        type: DataTypes.DECIMAL(11, 8),
        allowNull: true,
    },
    address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    riskLevel: {
        type: DataTypes.ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'),
        defaultValue: 'HIGH',
    },
    riskScore: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    audioRecordingPath: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    notes: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    resolvedAt: {
        type: DataTypes.DATE,
        allowNull: true,
    },
}, {
    tableName: 'emergency_alerts',
    timestamps: true,
});

module.exports = EmergencyAlert;
