const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const LocationHistory = sequelize.define('LocationHistory', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: 'users', key: 'id' },
    },
    alertId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: { model: 'emergency_alerts', key: 'id' },
    },
    latitude: {
        type: DataTypes.DECIMAL(10, 8),
        allowNull: false,
    },
    longitude: {
        type: DataTypes.DECIMAL(11, 8),
        allowNull: false,
    },
    accuracy: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    speed: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    isEmergency: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
    recordedAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'location_history',
    timestamps: true,
});

module.exports = LocationHistory;
