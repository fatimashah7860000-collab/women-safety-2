const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const SafeZone = sequelize.define('SafeZone', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING(150),
        allowNull: false,
    },
    type: {
        type: DataTypes.ENUM('POLICE_STATION', 'HOSPITAL', 'SAFE_ZONE', 'DANGER_ZONE'),
        allowNull: false,
    },
    latitude: {
        type: DataTypes.DECIMAL(10, 8),
        allowNull: false,
    },
    longitude: {
        type: DataTypes.DECIMAL(11, 8),
        allowNull: false,
    },
    address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    phone: {
        type: DataTypes.STRING(20),
        allowNull: true,
    },
    crimeRate: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        comment: '0-100 crime risk score',
    },
    isVerified: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
}, {
    tableName: 'safe_zones',
    timestamps: true,
});

module.exports = SafeZone;
