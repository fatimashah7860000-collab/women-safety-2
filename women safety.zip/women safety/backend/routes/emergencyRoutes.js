const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const {
    triggerSOS, updateLocation, resolveAlert,
    getAlertHistory, getRiskAnalysis, getDashboardStats,
    getSafeZones, uploadAudio
} = require('../controllers/emergencyController');
const { protect } = require('../middleware/authMiddleware');

// Audio upload storage
const audioDir = path.join(__dirname, '../uploads/audio');
if (!fs.existsSync(audioDir)) fs.mkdirSync(audioDir, { recursive: true });

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, audioDir),
    filename: (req, file, cb) => cb(null, `emergency_${Date.now()}.webm`)
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } }); // 50MB

// Routes
router.post('/sos', protect, triggerSOS);
router.put('/location', protect, updateLocation);
router.put('/:id/resolve', protect, resolveAlert);
router.get('/history', protect, getAlertHistory);
router.post('/risk-analysis', protect, getRiskAnalysis);
router.get('/stats', protect, getDashboardStats);
router.get('/safe-zones', protect, getSafeZones);
router.post('/upload-audio', protect, upload.single('audio'), uploadAudio);

module.exports = router;
