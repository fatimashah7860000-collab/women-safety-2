const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');

const EmergencyAlert = require('../models/EmergencyAlert');
const EmergencyContact = require('../models/EmergencyContact');
const User = require('../models/User');
const { Op } = require('sequelize');

// ─── GET all active emergencies (Admin Dashboard) ───────────────────────────
router.get('/emergencies', protect, async (req, res) => {
    try {
        const alerts = await EmergencyAlert.findAll({
            order: [['createdAt', 'DESC']],
            limit: 200,
        });

        // Attach user info to each alert
        const enriched = await Promise.all(alerts.map(async (alert) => {
            const user = await User.findByPk(alert.userId, {
                attributes: ['id', 'name', 'phone', 'email'],
            });
            const contacts = await EmergencyContact.findAll({
                where: { userId: alert.userId, isActive: true },
                attributes: ['name', 'phone', 'relation'],
            });
            return {
                ...alert.toJSON(),
                user: user ? { name: user.name, phone: user.phone, email: user.email } : null,
                emergencyContacts: contacts.map(c => ({ name: c.name, phone: c.phone, relation: c.relation })),
                mapLink: alert.latitude && alert.longitude
                    ? `https://www.google.com/maps?q=${alert.latitude},${alert.longitude}`
                    : null,
            };
        }));

        res.json({ success: true, data: enriched });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// ─── GET summary stats ──────────────────────────────────────────────────────
router.get('/stats', protect, async (req, res) => {
    try {
        const [total, active, resolved, users] = await Promise.all([
            EmergencyAlert.count(),
            EmergencyAlert.count({ where: { status: 'ACTIVE' } }),
            EmergencyAlert.count({ where: { status: 'RESOLVED' } }),
            User.count(),
        ]);
        res.json({ success: true, data: { total, active, resolved, users } });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// ─── PUT resolve / mark alert ───────────────────────────────────────────────
router.put('/emergencies/:id/resolve', protect, async (req, res) => {
    try {
        const alert = await EmergencyAlert.findByPk(req.params.id);
        if (!alert) return res.status(404).json({ success: false, message: 'Alert not found' });
        await alert.update({ status: req.body.status || 'RESOLVED', resolvedAt: new Date() });

        // Emit socket event so admin dashboard updates live
        const io = req.app.get('io');
        if (io) io.emit('alert_resolved', { alertId: alert.id, status: alert.status });

        res.json({ success: true, data: alert });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

module.exports = router;
