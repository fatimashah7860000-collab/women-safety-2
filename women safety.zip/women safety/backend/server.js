require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const morgan = require('morgan');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const { connectDB } = require('./config/database');
const authRoutes = require('./routes/authRoutes');
const emergencyRoutes = require('./routes/emergencyRoutes');
const contactRoutes = require('./routes/contactRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
const server = http.createServer(app);

// ========================
// Socket.IO Setup
// ========================
const io = new Server(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST'],
    },
});

app.set('io', io);

io.on('connection', (socket) => {
    console.log(`🔌 Client connected: ${socket.id}`);

    socket.on('join_room', (userId) => {
        socket.join(`user_${userId}`);
        console.log(`User ${userId} joined their safety room`);
    });

    socket.on('disconnect', () => {
        console.log(`🔌 Client disconnected: ${socket.id}`);
    });
});

// ========================
// Middleware
// ========================
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('dev'));
app.use(cors({ origin: '*', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    message: { success: false, message: 'Too many requests, please try again later.' },
});
app.use('/api/', limiter);

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ========================
// API Routes
// ========================
app.use('/api/auth', authRoutes);
app.use('/api/emergency', emergencyRoutes);
app.use('/api/contacts', contactRoutes);
app.use('/api/admin', adminRoutes);

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: '🛡️ Women Safety AI App Server is Running',
        version: '1.0.0',
        timestamp: new Date(),
        database: 'MySQL (Sequelize)',
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('❌ Server Error:', err.stack);
    res.status(err.status || 500).json({
        success: false,
        message: err.message || 'Internal Server Error',
    });
});

// ========================
// Start Server
// ========================
const PORT = process.env.PORT || 5000;

const startServer = async () => {
    await connectDB();

    server.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.error('\n❌ ======================================');
            console.error(`❌ Port ${PORT} is ALREADY IN USE!`);
            console.error(`❌ Another server instance is running.`);
            console.error('❌ Fix: Run this command first:');
            console.error('   powershell -Command "Get-Process node | Stop-Process -Force"');
            console.error('   Then run: npm start');
            console.error('❌ ======================================\n');
            process.exit(0);
        } else {
            console.error('Server error:', err);
            process.exit(1);
        }
    });

    server.listen(PORT, () => {
        console.log('\n======================================');
        console.log(`🛡️  Women Safety AI App Backend`);
        console.log(`🚀 Server running on http://localhost:${PORT}`);
        console.log(`🔗 API Base: http://localhost:${PORT}/api`);
        console.log(`🗄️  Database: MySQL (Sequelize)`);
        console.log('======================================\n');
    });
};

startServer();
