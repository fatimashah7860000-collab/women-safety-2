const API_BASE = 'http://localhost:5000/api';

// ===== TOKEN HELPERS =====
const getToken = () => localStorage.getItem('ws_token');
const getUser = () => {
    try { return JSON.parse(localStorage.getItem('ws_user')); } catch { return null; }
};
const setAuth = (user, token) => {
    localStorage.setItem('ws_token', token);
    localStorage.setItem('ws_user', JSON.stringify(user));
};
const clearAuth = () => {
    localStorage.removeItem('ws_token');
    localStorage.removeItem('ws_user');
};

// ===== FETCH HELPER =====
const apiCall = async (endpoint, method = 'GET', body = null, auth = true) => {
    const headers = { 'Content-Type': 'application/json' };
    if (auth && getToken()) headers['Authorization'] = `Bearer ${getToken()}`;

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    try {
        const res = await fetch(`${API_BASE}${endpoint}`, options);
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'API Error');
        return data;
    } catch (err) {
        throw err;
    }
};

// ===== TOAST NOTIFICATION =====
const showToast = (message, type = 'info') => {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<span>${icons[type]}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => toast.remove(), 3500);
};

// ===== AUTH GUARD =====
const requireAuth = () => {
    if (!getToken()) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
};

const redirectIfAuth = () => {
    if (getToken()) {
        window.location.href = 'dashboard.html';
        return true;
    }
    return false;
};

// ===== SET USER INFO IN NAV =====
const setNavUser = () => {
    const user = getUser();
    if (!user) return;
    const nameEl = document.getElementById('nav-user-name');
    const emailEl = document.getElementById('nav-user-email');
    if (nameEl) nameEl.textContent = user.name;
    if (emailEl) emailEl.textContent = user.email;
};

// ===== LOGOUT =====
const logout = () => {
    clearAuth();
    showToast('Logged out successfully', 'info');
    setTimeout(() => window.location.href = 'login.html', 500);
};

// ===== FORMAT DATE =====
const formatDate = (dateStr) => {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleString('en-IN', {
        day: '2-digit', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit',
    });
};

// ===== GET RISK BADGE =====
const getRiskBadge = (level) => {
    const badges = {
        CRITICAL: '<span class="badge badge-critical">🔴 CRITICAL</span>',
        HIGH: '<span class="badge badge-high">🟠 HIGH</span>',
        MEDIUM: '<span class="badge badge-medium">🟡 MEDIUM</span>',
        LOW: '<span class="badge badge-low">🟢 LOW</span>',
    };
    return badges[level] || badges['LOW'];
};

// ===== GEOLOCATION =====
const getCurrentPosition = () => {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error('Geolocation not supported'));
            return;
        }
        navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0,
        });
    });
};
