/**
 * ============================================================
 * Women Safety AI — Emergency Engine v3.0
 * ============================================================
 * TRIGGER 1: SOS Button Press       → triggerEmergency('SOS')
 * TRIGGER 2: Voice "HELP"           → Web Speech API (continuous)
 * TRIGGER 3: Phone Shake            → DeviceMotionEvent
 * TRIGGER 4: Auto AI Risk Detection → Interval-based risk check
 *
 * CALL SEQUENCE (on emergency):
 *   Step 1: Emergency Family Contacts (one by one, 15s each)
 *   Step 2: Police — 100
 *   Step 3: Women Helpline — 1091
 *   Step 4: National Emergency — 112
 * ============================================================
 */

const EmergencyEngine = (() => {

    // ── State ──────────────────────────────────────────────────
    let emergencyActive = false;
    let recognition = null;
    let voiceListening = false;
    let shakeLastX = null, shakeLastY = null, shakeLastZ = null;
    let shakeTimeout = null;
    let autoRiskInterval = null;
    let mediaRecorder = null;
    let audioChunks = [];
    let locationWatchId = null;
    let callSequenceTimer = null;
    let callSequenceCancelled = false;
    let currentAlertId = null;

    // ── Callbacks ──────────────────────────────────────────────
    let _onTrigger = null;
    let _onLocation = null;
    let _onRisk = null;
    let _onStatus = null;
    let _onCallStep = null; // {step, name, phone, total}

    const onTrigger = (cb) => { _onTrigger = cb; };
    const onLocation = (cb) => { _onLocation = cb; };
    const onRisk = (cb) => { _onRisk = cb; };
    const onStatus = (cb) => { _onStatus = cb; };
    const onCallStep = (cb) => { _onCallStep = cb; };

    const emit = (type, status, message) => {
        if (_onStatus) _onStatus({ type, status, message });
        console.log(`[Engine] ${type}: ${status} — ${message}`);
    };

    // ============================================================
    // TRIGGER 2 — VOICE RECOGNITION ("HELP" keyword)
    // ============================================================
    const initVoice = () => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            emit('voice', 'unsupported', 'Voice recognition not supported in this browser');
            return false;
        }

        const startRecognition = () => {
            recognition = new SpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.lang = 'en-IN';
            recognition.maxAlternatives = 5;

            const KEYWORDS = [
                'help', 'help me', 'save me', 'bachao', 'bachao mujhe',
                'danger', 'mayday', 'emergency', 'sos', 'police', 'fire', 'madad'
            ];

            recognition.onstart = () => {
                voiceListening = true;
                emit('voice', 'active', 'Listening for HELP / Bachao...');
            };

            recognition.onresult = (e) => {
                for (let i = e.resultIndex; i < e.results.length; i++) {
                    for (let j = 0; j < e.results[i].length; j++) {
                        const transcript = e.results[i][j].transcript.toLowerCase().trim();
                        // Update voice feed if on emergency page
                        const feed = document.getElementById('voice-feed');
                        if (feed) feed.textContent = `"${transcript}"`;
                        if (KEYWORDS.some(kw => transcript.includes(kw))) {
                            console.log('🎙️ VOICE TRIGGER:', transcript);
                            emit('voice', 'triggered', `Detected: "${transcript}"`);
                            recognition.stop();
                            triggerEmergency('VOICE');
                            return;
                        }
                    }
                }
            };

            recognition.onerror = (e) => {
                if (e.error === 'not-allowed') {
                    voiceListening = false;
                    emit('voice', 'denied', 'Mic permission denied by user');
                    return;
                }
                if (e.error !== 'no-speech' && e.error !== 'aborted') {
                    emit('voice', 'error', `Error: ${e.error}`);
                }
            };

            recognition.onend = () => {
                voiceListening = false;
                if (!emergencyActive) {
                    setTimeout(() => {
                        try { startRecognition(); } catch (e) { }
                    }, 1000);
                }
            };

            try {
                recognition.start();
                return true;
            } catch (e) {
                emit('voice', 'error', e.message);
                return false;
            }
        };

        startRecognition();
        return true;
    };

    // ============================================================
    // TRIGGER 3 — SHAKE DETECTION (DeviceMotionEvent)
    // ============================================================
    const SHAKE_THRESHOLD = 18;
    const SHAKE_COOLDOWN = 3000;

    const handleMotion = (event) => {
        const acc = event.accelerationIncludingGravity;
        if (!acc || acc.x === null) return;

        const x = acc.x || 0, y = acc.y || 0, z = acc.z || 0;

        if (shakeLastX === null) {
            shakeLastX = x; shakeLastY = y; shakeLastZ = z;
            return;
        }

        const delta = Math.sqrt(
            Math.pow(x - shakeLastX, 2) +
            Math.pow(y - shakeLastY, 2) +
            Math.pow(z - shakeLastZ, 2)
        );

        shakeLastX = x; shakeLastY = y; shakeLastZ = z;

        // Update shake bar if on emergency page
        const bar = document.getElementById('shake-bar');
        if (bar) {
            const pct = Math.min(100, (delta / SHAKE_THRESHOLD) * 100);
            bar.style.width = pct + '%';
        }

        if (delta > SHAKE_THRESHOLD && !shakeTimeout) {
            console.log('📳 SHAKE TRIGGER! Delta:', delta.toFixed(2));
            emit('shake', 'triggered', `Shake detected (${delta.toFixed(1)} m/s²)`);
            shakeTimeout = setTimeout(() => { shakeTimeout = null; }, SHAKE_COOLDOWN);
            triggerEmergency('SHAKE');
        }
    };

    const initShake = () => {
        if (!window.DeviceMotionEvent) {
            emit('shake', 'unsupported', 'Shake detection requires a mobile device');
            return false;
        }

        if (typeof DeviceMotionEvent.requestPermission === 'function') {
            DeviceMotionEvent.requestPermission()
                .then(perm => {
                    if (perm === 'granted') {
                        window.addEventListener('devicemotion', handleMotion);
                        emit('shake', 'active', 'Shake detection ON (iOS)');
                    } else {
                        emit('shake', 'denied', 'Motion permission denied');
                    }
                })
                .catch(e => emit('shake', 'error', e.message));
        } else {
            window.addEventListener('devicemotion', handleMotion);
            emit('shake', 'active', 'Shake detection ON');
        }
        return true;
    };

    // ============================================================
    // TRIGGER 4 — AUTO AI RISK DETECTION
    // ============================================================
    const AUTO_CHECK_INTERVAL = 60000;
    const AUTO_TRIGGER_SCORE = 85;

    const initAutoRisk = () => {
        emit('auto', 'active', 'AI background monitor ON (checks every 60s)');

        autoRiskInterval = setInterval(async () => {
            if (emergencyActive) return;

            const lat = window._currentLat || null;
            const lng = window._currentLng || null;
            if (!lat) return;

            try {
                const hour = new Date().getHours();
                const night = (hour >= 22 || hour <= 5) ? 40 : (hour >= 20 || hour <= 7) ? 25 : 5;
                const base = Math.floor(Math.random() * 30) + 10;
                const score = Math.min(100, night + base);

                if (_onRisk) _onRisk({ riskLevel: getRiskLevel(score), riskScore: score, auto: true });

                if (score >= AUTO_TRIGGER_SCORE) {
                    emit('auto', 'triggered', `Auto risk score: ${score} — triggering emergency`);
                    triggerEmergency('AUTO');
                } else {
                    emit('auto', 'active', `AI check OK — Risk: ${score}/100 at ${new Date().toLocaleTimeString()}`);
                }
            } catch (e) { }
        }, AUTO_CHECK_INTERVAL);

        return true;
    };

    const getRiskLevel = (score) => {
        if (score >= 75) return 'CRITICAL';
        if (score >= 55) return 'HIGH';
        if (score >= 35) return 'MEDIUM';
        return 'LOW';
    };

    // ============================================================
    // AUDIO RECORDING (Evidence Collection)
    // ============================================================
    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            audioChunks = [];
            let mimeType = 'audio/webm;codecs=opus';
            if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'audio/webm';
            mediaRecorder = new MediaRecorder(stream, { mimeType });

            mediaRecorder.ondataavailable = (e) => {
                if (e.data && e.data.size > 0) audioChunks.push(e.data);
            };

            mediaRecorder.onstop = async () => {
                const blob = new Blob(audioChunks, { type: 'audio/webm' });
                window._emergencyAudioBlob = blob;
                window._emergencyAudioUrl = URL.createObjectURL(blob);
                emit('audio', 'saved', `Recording saved (${(blob.size / 1024).toFixed(0)} KB)`);
                stream.getTracks().forEach(t => t.stop());

                // Upload to backend
                if (currentAlertId) {
                    try {
                        const token = typeof getToken === 'function' ? getToken() : null;
                        if (token) {
                            const fd = new FormData();
                            fd.append('audio', blob, 'emergency.webm');
                            fd.append('alertId', currentAlertId);
                            await fetch('http://localhost:5000/api/emergency/upload-audio', {
                                method: 'POST',
                                headers: { 'Authorization': `Bearer ${token}` },
                                body: fd,
                            });
                            emit('audio', 'uploaded', 'Audio evidence uploaded to server');
                        }
                    } catch (e) { emit('audio', 'error', 'Upload failed: ' + e.message); }
                }
            };

            mediaRecorder.start(2000);
            emit('audio', 'recording', 'Audio evidence recording...');
            return true;
        } catch (e) {
            emit('audio', 'error', `Mic error: ${e.message}`);
            return false;
        }
    };

    const stopRecording = () => {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    };

    // ============================================================
    // GPS LIVE TRACKING
    // ============================================================
    const startLocationTracking = (alertId) => {
        if (!navigator.geolocation) return;

        locationWatchId = navigator.geolocation.watchPosition(
            async (pos) => {
                const { latitude, longitude, accuracy, speed } = pos.coords;
                window._currentLat = latitude;
                window._currentLng = longitude;

                if (_onLocation) _onLocation({ latitude, longitude, accuracy, speed });

                const token = typeof getToken === 'function' ? getToken() : null;
                if (alertId && token) {
                    try {
                        await fetch('http://localhost:5000/api/emergency/location', {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                            body: JSON.stringify({ latitude, longitude, alertId, speed: speed || 0, accuracy: accuracy || 0 })
                        });
                    } catch (e) { }
                }
            },
            (err) => emit('gps', 'error', `GPS: ${err.message}`),
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 1000 }
        );
        emit('gps', 'active', 'Live GPS tracking started');
    };

    const stopLocationTracking = () => {
        if (locationWatchId !== null) {
            navigator.geolocation.clearWatch(locationWatchId);
            locationWatchId = null;
        }
    };

    // ============================================================
    // SMART CALL SEQUENCE
    //   1. Emergency contacts (one by one, 15s gap each)
    //   2. Police — 100
    //   3. Women helpline — 1091
    //   4. National emergency — 112
    // ============================================================
    const runCallSequence = async (contacts, lat, lng) => {
        const mapLink = `https://www.google.com/maps?q=${lat},${lng}`;
        callSequenceCancelled = false;

        // Build full call list: family contacts first, then police → 1091 → 112
        const callList = [
            ...contacts.map(c => ({ name: c.name, phone: c.phone, type: 'family' })),
            { name: 'Police', phone: '100', type: 'police' },
            { name: 'Women Helpline', phone: '1091', type: 'helpline' },
            { name: 'National Emergency', phone: '112', type: 'emergency' },
        ];

        emit('call', 'started', `Call sequence started — ${callList.length} numbers`);

        for (let i = 0; i < callList.length; i++) {
            if (callSequenceCancelled) break;

            const person = callList[i];
            const remaining = callList.length - i;

            emit('call', 'calling', `Calling ${person.name} (${person.phone})...`);

            if (_onCallStep) {
                _onCallStep({
                    step: i + 1,
                    total: callList.length,
                    name: person.name,
                    phone: person.phone,
                    type: person.type,
                    mapLink,
                    remaining,
                });
            }

            // Open the dialer
            window._openCall = () => { window.location.href = `tel:${person.phone}`; };

            // Auto-open dialer after 2 seconds (first call)
            if (i === 0) {
                setTimeout(() => {
                    if (!callSequenceCancelled) {
                        window.location.href = `tel:${person.phone}`;
                    }
                }, 2000);
            }

            // Wait 15 seconds before next call
            await new Promise(resolve => {
                callSequenceTimer = setTimeout(resolve, 15000);
            });
        }

        if (!callSequenceCancelled) {
            emit('call', 'completed', 'All emergency contacts called');
        }
    };

    const cancelCallSequence = () => {
        callSequenceCancelled = true;
        if (callSequenceTimer) {
            clearTimeout(callSequenceTimer);
            callSequenceTimer = null;
        }
        emit('call', 'cancelled', 'Call sequence cancelled by user');
    };

    // ============================================================
    // ADMIN NOTIFICATION via Socket.IO
    // ============================================================
    const notifyAdmin = (alertData) => {
        // If socket.io is loaded on the page, emit to admin room
        if (window.io) {
            const socket = window.io('http://localhost:5000');
            socket.emit('admin_notify', alertData);
        }
    };

    // ============================================================
    // MAIN TRIGGER — called by ALL 4 methods
    // ============================================================
    const triggerEmergency = async (type) => {
        if (emergencyActive) {
            console.log('⚠️ Emergency already active — ignoring duplicate trigger');
            return;
        }
        emergencyActive = true;

        console.log(`\n🚨🚨🚨 EMERGENCY TRIGGERED [${type}] at ${new Date().toLocaleTimeString()} 🚨🚨🚨`);
        emit('engine', 'triggered', `${type} emergency activated`);

        // Notify UI immediately
        if (_onTrigger) _onTrigger(type);

        // Vibrate SOS pattern
        if (navigator.vibrate) {
            navigator.vibrate([200, 100, 200, 100, 200, 500, 600, 300, 600, 300, 600, 500, 200, 100, 200, 100, 200]);
        }

        // Get precise location
        let lat = window._currentLat || 28.6139;
        let lng = window._currentLng || 77.2090;
        try {
            const pos = await new Promise((res, rej) =>
                navigator.geolocation.getCurrentPosition(res, rej, { enableHighAccuracy: true, timeout: 6000 })
            );
            lat = pos.coords.latitude;
            lng = pos.coords.longitude;
            window._currentLat = lat;
            window._currentLng = lng;
            emit('gps', 'done', `📍 ${lat.toFixed(5)}, ${lng.toFixed(5)}`);
        } catch (e) {
            emit('gps', 'error', 'Using last known location');
        }

        // Start audio recording
        const recorded = await startRecording();
        if (!recorded) emit('audio', 'skip', 'Mic unavailable — continuing without recording');

        // POST to backend → save alert + notify admin via socket
        let alertId = null;
        let riskData = null;
        let contacts = [];
        const token = typeof getToken === 'function' ? getToken() : null;

        if (token) {
            try {
                const resp = await fetch('http://localhost:5000/api/emergency/sos', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                    body: JSON.stringify({
                        alertType: type,
                        latitude: lat,
                        longitude: lng,
                        address: `${lat.toFixed(5)}, ${lng.toFixed(5)}`
                    })
                });
                const data = await resp.json();
                if (data.success) {
                    alertId = data.data.alertId;
                    currentAlertId = alertId;
                    riskData = data.data;
                    contacts = data.data.contacts || [];
                    emit('backend', 'done', `Alert #${alertId} saved — Risk: ${data.data.riskLevel}`);
                    if (_onRisk) _onRisk(data.data);
                }
            } catch (e) {
                emit('backend', 'error', 'Offline mode — alert logged locally');
                riskData = { riskLevel: 'HIGH', riskScore: 72, safetyTips: ['Call 112', 'Move to safe area'] };
                if (_onRisk) _onRisk(riskData);
            }
        } else {
            riskData = { riskLevel: 'HIGH', riskScore: 72, safetyTips: ['Call 112 immediately', 'Move to open area'] };
            if (_onRisk) _onRisk(riskData);
        }

        // Start live GPS tracking
        startLocationTracking(alertId);

        // Fetch emergency contacts if not received from server
        if (contacts.length === 0 && token) {
            try {
                const cr = await fetch('http://localhost:5000/api/contacts', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                const cd = await cr.json();
                if (cd.success && cd.data) {
                    contacts = cd.data.filter(c => c.isActive).map(c => ({ name: c.name, phone: c.phone }));
                }
            } catch (e) { }
        }

        // Emit to admin (socket)
        notifyAdmin({
            alertId, type, lat, lng,
            mapLink: `https://www.google.com/maps?q=${lat},${lng}`,
            riskLevel: riskData?.riskLevel,
            contacts,
            timestamp: new Date().toISOString(),
        });

        // Start smart call sequence
        emit('call', 'preparing', `Smart call sequence: ${contacts.length} contacts → Police → 1091 → 112`);
        runCallSequence(contacts, lat, lng);

        return alertId;
    };

    // ============================================================
    // DEACTIVATE
    // ============================================================
    const deactivate = () => {
        emergencyActive = false;
        currentAlertId = null;
        cancelCallSequence();
        stopRecording();
        stopLocationTracking();
        emit('engine', 'idle', 'Emergency deactivated — back to monitoring');
        console.log('✅ Emergency deactivated');
    };

    const simulateShake = () => {
        emit('shake', 'triggered', 'Shake simulated (desktop mode)');
        triggerEmergency('SHAKE');
    };

    const getStatus = () => ({
        emergencyActive,
        voiceListening,
        shakeReady: !!window.DeviceMotionEvent,
        autoMonitor: !!autoRiskInterval,
        currentAlertId,
    });

    // ============================================================
    // INIT
    // ============================================================
    const init = () => {
        console.log('🛡️ Emergency Engine v3.0 initializing...');
        emit('engine', 'starting', 'Initializing all 4 triggers...');

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                pos => {
                    window._currentLat = pos.coords.latitude;
                    window._currentLng = pos.coords.longitude;
                    emit('gps', 'ready', `Location: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
                },
                () => emit('gps', 'error', 'GPS unavailable — will retry on trigger')
            );
        }

        initVoice();
        initShake();
        initAutoRisk();

        emit('engine', 'ready', 'All 4 emergency triggers active ✅');
        console.log('✅ Engine ready — Trigger 1:SOS, 2:Voice, 3:Shake, 4:Auto all armed');
    };

    return {
        init, triggerEmergency, deactivate, simulateShake,
        getStatus, cancelCallSequence,
        onTrigger, onLocation, onRisk, onStatus, onCallStep,
    };

})();
