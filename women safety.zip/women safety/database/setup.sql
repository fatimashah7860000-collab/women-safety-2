-- ============================================
-- Women Safety AI App — MySQL Database Setup
-- Run this in MySQL Workbench before starting
-- ============================================

-- 1. Create Database
CREATE DATABASE IF NOT EXISTS women_safety_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE women_safety_db;

-- 2. Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password VARCHAR(255) NOT NULL,
  address TEXT,
  profilePhoto VARCHAR(255),
  isActive BOOLEAN DEFAULT TRUE,
  lastLocation JSON,
  safetyScore INT DEFAULT 100,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 3. Emergency Contacts Table
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  relation VARCHAR(50) NOT NULL,
  email VARCHAR(150),
  isActive BOOLEAN DEFAULT TRUE,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

-- 4. Emergency Alerts Table
CREATE TABLE IF NOT EXISTS emergency_alerts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT NOT NULL,
  alertType ENUM('SOS','VOICE','SHAKE','AUTO') DEFAULT 'SOS',
  status ENUM('ACTIVE','RESOLVED','FALSE_ALARM') DEFAULT 'ACTIVE',
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  address TEXT,
  riskLevel ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'HIGH',
  riskScore INT DEFAULT 0,
  audioRecordingPath VARCHAR(255),
  notes TEXT,
  resolvedAt DATETIME,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

-- 5. Location History Table
CREATE TABLE IF NOT EXISTS location_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT NOT NULL,
  alertId INT,
  latitude DECIMAL(10,8) NOT NULL,
  longitude DECIMAL(11,8) NOT NULL,
  accuracy FLOAT,
  speed FLOAT,
  address TEXT,
  isEmergency BOOLEAN DEFAULT FALSE,
  recordedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (alertId) REFERENCES emergency_alerts(id) ON DELETE SET NULL
);

-- 6. Safe Zones Table
CREATE TABLE IF NOT EXISTS safe_zones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  type ENUM('POLICE_STATION','HOSPITAL','SAFE_ZONE','DANGER_ZONE') NOT NULL,
  latitude DECIMAL(10,8) NOT NULL,
  longitude DECIMAL(11,8) NOT NULL,
  address TEXT,
  phone VARCHAR(20),
  crimeRate INT DEFAULT 0 COMMENT '0-100 crime risk score',
  isVerified BOOLEAN DEFAULT FALSE,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- Sample Data (Optional for Demo/Testing)
-- ============================================

-- Sample Police Stations
INSERT INTO safe_zones (name, type, latitude, longitude, address, phone, crimeRate, isVerified) VALUES
('Connaught Place Police Station', 'POLICE_STATION', 28.6315, 77.2167, 'Connaught Place, New Delhi', '011-23341002', 20, TRUE),
('Andheri Police Station', 'POLICE_STATION', 19.1197, 72.8468, 'Andheri, Mumbai', '022-26251234', 35, TRUE),
('Koramangala Police Station', 'POLICE_STATION', 12.9352, 77.6245, 'Koramangala, Bengaluru', '080-22942000', 25, TRUE),
('Apollo Hospital Delhi', 'HOSPITAL', 28.5672, 77.2100, 'Sarita Vihar, New Delhi', '011-71791090', 5, TRUE),
('Lilavati Hospital Mumbai', 'HOSPITAL', 19.0490, 72.8257, 'Bandra, Mumbai', '022-26751000', 10, TRUE);

-- ============================================
-- Verify Tables Created
-- ============================================
SHOW TABLES;
SELECT 'Women Safety AI Database Setup Complete! ✅' AS Status;
